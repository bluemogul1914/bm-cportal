/**
 * routes/dealer.js
 * Blue Mogul bm-cportal — Dealer Module Routes
 *
 * Mount in app.js:
 *   const dealerRoutes = require('./routes/dealer');
 *   app.use('/api/dealer', dealerRoutes);
 *   app.use('/api/webhook', dealerRoutes); // for activation webhook
 *
 * Auth middleware (reuse portal's existing session/role check):
 *   requireDealer  — dealer must be logged in (role = 'dealer')
 *   requireAdmin   — admin only
 *   webhookAuth    — x-webhook-token header check (same as existing webhooks)
 */

const express = require('express');
const router  = express.Router();
const { Pool } = require('pg');
const crypto  = require('crypto');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// ── Helpers ──────────────────────────────────────────────────

function cents(dollars) { return Math.round(dollars * 100); }
function dollars(c)     { return (c / 100).toFixed(2); }

function genOrderRef() {
  const d = new Date();
  const pad = n => String(n).padStart(2,'0');
  const rand = String(Math.floor(Math.random() * 9999)).padStart(4,'0');
  return `ORD-${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}-${rand}`;
}

function genDealerCode() {
  return 'DLR-' + String(Math.floor(10000 + Math.random() * 90000));
}

// Reuse portal's existing webhook auth pattern
function webhookAuth(req, res, next) {
  const token = req.headers['x-webhook-token'];
  if (!token || token !== process.env.WEBHOOK_SECRET) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
}

// Lightweight dealer session check — adapt to your portal's actual session lib
function requireDealer(req, res, next) {
  if (!req.session || req.session.role !== 'dealer') {
    return res.status(403).json({ error: 'Dealer login required' });
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session || req.session.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

// ── DEALER SELF-REGISTRATION ─────────────────────────────────

// POST /api/dealer/register
// Public — dealer signs up, status starts as 'pending' (admin approves)
router.post('/register', async (req, res) => {
  const { full_name, email, phone, company } = req.body;
  if (!full_name || !email) {
    return res.status(400).json({ error: 'full_name and email are required' });
  }
  try {
    const dealer_code = genDealerCode();
    const result = await pool.query(
      `INSERT INTO dealers (dealer_code, full_name, email, phone, company)
       VALUES ($1,$2,$3,$4,$5)
       RETURNING id, dealer_code, status`,
      [dealer_code, full_name, email, phone || null, company || null]
    );
    res.json({ success: true, dealer: result.rows[0] });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'Email already registered' });
    console.error('dealer register error:', err);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// ── DEALER DASHBOARD ─────────────────────────────────────────

// GET /api/dealer/dashboard
router.get('/dashboard', requireDealer, async (req, res) => {
  const dealer_id = req.session.dealer_id;
  try {
    const [dealer, mtdStats, recentOrders, pendingPayout] = await Promise.all([

      pool.query(
        `SELECT dealer_code, full_name, tier, activations_mtd FROM dealers WHERE id=$1`,
        [dealer_id]
      ),

      pool.query(
        `SELECT
           COALESCE(SUM(c.amount_cents) FILTER (WHERE c.status='approved'), 0) AS approved_cents,
           COALESCE(SUM(c.amount_cents) FILTER (WHERE c.status='paid'), 0)     AS paid_cents,
           COUNT(*) FILTER (WHERE o.status='activated'
             AND o.activated_at >= date_trunc('month', NOW()))                  AS activations_mtd
         FROM dealer_orders o
         LEFT JOIN commissions c ON c.order_id = o.id
         WHERE o.dealer_id = $1`,
        [dealer_id]
      ),

      pool.query(
        `SELECT o.order_ref, o.client_name, o.product_line, o.plan_name,
                o.status, o.created_at, c.amount_cents, c.status AS commission_status
         FROM dealer_orders o
         LEFT JOIN commissions c ON c.order_id = o.id
         WHERE o.dealer_id = $1
         ORDER BY o.created_at DESC LIMIT 10`,
        [dealer_id]
      ),

      pool.query(
        `SELECT COALESCE(SUM(amount_cents),0) AS pending_cents
         FROM commissions
         WHERE dealer_id=$1 AND status='approved'`,
        [dealer_id]
      )
    ]);

    res.json({
      dealer:        dealer.rows[0],
      mtd_earned:    dollars(mtdStats.rows[0].approved_cents),
      pending_payout: dollars(pendingPayout.rows[0].pending_cents),
      recent_orders: recentOrders.rows.map(r => ({
        ...r,
        spiff: r.amount_cents ? dollars(r.amount_cents) : null
      }))
    });
  } catch (err) {
    console.error('dashboard error:', err);
    res.status(500).json({ error: 'Failed to load dashboard' });
  }
});

// ── SPIFF SCHEDULE (public read) ─────────────────────────────

// GET /api/dealer/spiffs
router.get('/spiffs', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT product_line, tier, spiff_cents, markets, notes
       FROM spiff_schedule
       WHERE active = TRUE
       ORDER BY product_line, tier`
    );
    res.json({ spiffs: result.rows.map(r => ({ ...r, spiff: dollars(r.spiff_cents) })) });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load spiff schedule' });
  }
});

// ── SUBMIT ORDER ─────────────────────────────────────────────

// POST /api/dealer/orders
router.post('/orders', requireDealer, async (req, res) => {
  const dealer_id = req.session.dealer_id;
  const {
    client_name, client_email, client_phone,
    service_address, product_line, plan_name,
    plan_price, dealer_notes
  } = req.body;

  if (!client_name || !product_line) {
    return res.status(400).json({ error: 'client_name and product_line are required' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Get dealer tier to look up correct spiff
    const dealerRow = await client.query(
      `SELECT tier, status FROM dealers WHERE id=$1`, [dealer_id]
    );
    if (!dealerRow.rows[0] || dealerRow.rows[0].status !== 'active') {
      await client.query('ROLLBACK');
      return res.status(403).json({ error: 'Dealer account not active' });
    }

    const tier = dealerRow.rows[0].tier;

    // Look up spiff
    const spiffRow = await client.query(
      `SELECT spiff_cents FROM spiff_schedule
       WHERE product_line=$1 AND tier=$2 AND active=TRUE
       ORDER BY effective_from DESC LIMIT 1`,
      [product_line, tier]
    );
    const spiff_cents = spiffRow.rows[0]?.spiff_cents || 0;

    const order_ref = genOrderRef();

    const order = await client.query(
      `INSERT INTO dealer_orders
         (dealer_id, order_ref, client_name, client_email, client_phone,
          service_address, product_line, plan_name,
          plan_price_cents, spiff_cents, tier_at_order, dealer_notes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
       RETURNING id, order_ref, spiff_cents`,
      [
        dealer_id, order_ref, client_name, client_email || null,
        client_phone || null, service_address || null,
        product_line, plan_name || null,
        plan_price ? cents(plan_price) : null,
        spiff_cents, tier, dealer_notes || null
      ]
    );

    await client.query('COMMIT');

    // Log to agent_logs (matches existing portal pattern)
    await pool.query(
      `INSERT INTO agent_logs (agent_key, action, status, message, metadata)
       VALUES ('DEALER_MODULE', 'order_submitted', 'success', $1, $2)`,
      [
        `Order ${order_ref} submitted by dealer ${dealer_id}`,
        JSON.stringify({ order_ref, product_line, dealer_id })
      ]
    ).catch(() => {}); // non-fatal

    res.json({
      success: true,
      order_ref,
      spiff: dollars(spiff_cents),
      message: 'Order submitted. Commission releases on confirmed activation.'
    });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('order submit error:', err);
    res.status(500).json({ error: 'Order submission failed' });
  } finally {
    client.release();
  }
});

// ── COMMISSIONS ──────────────────────────────────────────────

// GET /api/dealer/commissions
router.get('/commissions', requireDealer, async (req, res) => {
  const dealer_id = req.session.dealer_id;
  try {
    const result = await pool.query(
      `SELECT c.id, c.amount_cents, c.status, c.approved_at, c.paid_at,
              o.order_ref, o.client_name, o.product_line, o.created_at AS order_date
       FROM commissions c
       JOIN dealer_orders o ON o.id = c.order_id
       WHERE c.dealer_id = $1
       ORDER BY c.created_at DESC`,
      [dealer_id]
    );
    res.json({
      commissions: result.rows.map(r => ({ ...r, amount: dollars(r.amount_cents) }))
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load commissions' });
  }
});

// ── PAYOUTS ───────────────────────────────────────────────────

// GET /api/dealer/payouts
router.get('/payouts', requireDealer, async (req, res) => {
  const dealer_id = req.session.dealer_id;
  try {
    const [history, available] = await Promise.all([
      pool.query(
        `SELECT id, amount_cents, commission_count, status, sent_at, created_at
         FROM dealer_payouts WHERE dealer_id=$1 ORDER BY created_at DESC`,
        [dealer_id]
      ),
      pool.query(
        `SELECT COALESCE(SUM(amount_cents),0) AS available_cents
         FROM commissions WHERE dealer_id=$1 AND status='approved'`,
        [dealer_id]
      )
    ]);
    res.json({
      available: dollars(available.rows[0].available_cents),
      history: history.rows.map(r => ({ ...r, amount: dollars(r.amount_cents) }))
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load payouts' });
  }
});

// POST /api/dealer/payouts/request — dealer requests early payout
router.post('/payouts/request', requireDealer, async (req, res) => {
  const dealer_id = req.session.dealer_id;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const avail = await client.query(
      `SELECT id, amount_cents FROM commissions
       WHERE dealer_id=$1 AND status='approved' FOR UPDATE`,
      [dealer_id]
    );
    if (!avail.rows.length) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'No approved commissions available' });
    }

    const total = avail.rows.reduce((s, r) => s + r.amount_cents, 0);
    const payout = await client.query(
      `INSERT INTO dealer_payouts
         (dealer_id, amount_cents, commission_count, status)
       VALUES ($1,$2,$3,'pending')
       RETURNING id`,
      [dealer_id, total, avail.rows.length]
    );
    const payout_id = payout.rows[0].id;

    // Mark commissions as paid and link to payout
    const ids = avail.rows.map(r => r.id);
    await client.query(
      `UPDATE commissions SET status='paid', paid_at=NOW(), payout_id=$1
       WHERE id = ANY($2)`,
      [payout_id, ids]
    );

    await client.query('COMMIT');
    res.json({ success: true, payout_id, amount: dollars(total) });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('payout request error:', err);
    res.status(500).json({ error: 'Payout request failed' });
  } finally {
    client.release();
  }
});

// ── ACTIVATION WEBHOOK ───────────────────────────────────────
// POST /api/webhook/dealer-activation
// Called by UISP / CLOUDMASTER / N8N when service is confirmed active
// Headers: x-webhook-token (same secret as all portal webhooks)
//
// Body: { order_ref, payment_ref, activated_at? }
//   OR: { product_line, client_email, payment_ref }  (for non-order-ref flows)
//
router.post('/dealer-activation', webhookAuth, async (req, res) => {
  const { order_ref, payment_ref, activated_at, client_email, product_line } = req.body;

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Find the order
    let orderRow;
    if (order_ref) {
      const r = await client.query(
        `SELECT id, dealer_id, spiff_cents, status FROM dealer_orders
         WHERE order_ref=$1 FOR UPDATE`,
        [order_ref]
      );
      orderRow = r.rows[0];
    } else if (client_email && product_line) {
      const r = await client.query(
        `SELECT id, dealer_id, spiff_cents, status FROM dealer_orders
         WHERE client_email=$1 AND product_line=$2 AND status='submitted'
         ORDER BY created_at DESC LIMIT 1 FOR UPDATE`,
        [client_email, product_line]
      );
      orderRow = r.rows[0];
    }

    if (!orderRow) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Order not found' });
    }
    if (orderRow.status === 'activated') {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'Order already activated' });
    }

    // Mark order activated
    await client.query(
      `UPDATE dealer_orders SET
         status='activated',
         payment_ref=$1,
         activated_at=COALESCE($2::timestamptz, NOW()),
         updated_at=NOW()
       WHERE id=$3`,
      [payment_ref || null, activated_at || null, orderRow.id]
    );

    // Create commission record
    await client.query(
      `INSERT INTO commissions (dealer_id, order_id, amount_cents, status, approved_at)
       VALUES ($1,$2,$3,'approved',NOW())`,
      [orderRow.dealer_id, orderRow.id, orderRow.spiff_cents]
    );

    // Increment dealer's monthly activation count and update tier
    await client.query(
      `UPDATE dealers SET
         activations_mtd = activations_mtd + 1,
         updated_at = NOW()
       WHERE id=$1`,
      [orderRow.dealer_id]
    );
    await client.query(
      `SELECT update_dealer_tier($1)`, [orderRow.dealer_id]
    );

    await client.query('COMMIT');

    // Log it
    await pool.query(
      `INSERT INTO agent_logs (agent_key, action, status, message, metadata)
       VALUES ('DEALER_MODULE','activation_webhook','success',$1,$2)`,
      [
        `Order ${orderRow.id} activated — commission $${dollars(orderRow.spiff_cents)} queued`,
        JSON.stringify({ order_id: orderRow.id, dealer_id: orderRow.dealer_id, spiff_cents: orderRow.spiff_cents })
      ]
    ).catch(() => {});

    res.json({
      success: true,
      commission_queued: dollars(orderRow.spiff_cents),
      dealer_id: orderRow.dealer_id
    });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('activation webhook error:', err);
    res.status(500).json({ error: 'Activation processing failed' });
  } finally {
    client.release();
  }
});

// ── ADMIN: approve dealer registration ───────────────────────
// POST /api/dealer/admin/approve/:id
router.post('/admin/approve/:id', requireAdmin, async (req, res) => {
  try {
    await pool.query(
      `UPDATE dealers SET status='active', updated_at=NOW() WHERE id=$1`,
      [req.params.id]
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Approval failed' });
  }
});

// ── ADMIN: pending dealer list ────────────────────────────────
// GET /api/dealer/admin/pending
router.get('/admin/pending', requireAdmin, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, dealer_code, full_name, email, company, created_at
       FROM dealers WHERE status='pending' ORDER BY created_at DESC`
    );
    res.json({ dealers: result.rows });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load pending dealers' });
  }
});

// ── ADMIN: trigger weekly payout batch ───────────────────────
// POST /api/dealer/admin/run-payouts
// Call this via N8N every Friday or manually
router.post('/admin/run-payouts', requireAdmin, async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Get all dealers with approved commissions
    const dealers = await client.query(
      `SELECT dealer_id, SUM(amount_cents) AS total, COUNT(*) AS cnt
       FROM commissions WHERE status='approved'
       GROUP BY dealer_id`
    );

    const results = [];
    for (const row of dealers.rows) {
      const payout = await client.query(
        `INSERT INTO dealer_payouts
           (dealer_id, amount_cents, commission_count, status, initiated_at)
         VALUES ($1,$2,$3,'processing',NOW())
         RETURNING id`,
        [row.dealer_id, row.total, row.cnt]
      );
      const payout_id = payout.rows[0].id;
      await client.query(
        `UPDATE commissions SET status='paid', paid_at=NOW(), payout_id=$1
         WHERE dealer_id=$2 AND status='approved'`,
        [payout_id, row.dealer_id]
      );
      results.push({ dealer_id: row.dealer_id, payout_id, amount: dollars(row.total) });
    }

    await client.query('COMMIT');
    res.json({ success: true, payouts_initiated: results });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('run-payouts error:', err);
    res.status(500).json({ error: 'Payout batch failed' });
  } finally {
    client.release();
  }
});

module.exports = router;
