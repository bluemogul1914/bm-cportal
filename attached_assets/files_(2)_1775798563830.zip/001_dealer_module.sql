-- ============================================================
-- Blue Mogul bm-cportal — Dealer Module Migration
-- Run via: psql $DATABASE_URL -f 001_dealer_module.sql
-- Safe: all CREATE TABLE IF NOT EXISTS — won't touch existing tables
-- ============================================================

-- ── 1. DEALERS ──────────────────────────────────────────────
-- One row per registered dealer/ISO
CREATE TABLE IF NOT EXISTS dealers (
  id               SERIAL PRIMARY KEY,
  dealer_code      VARCHAR(12)  NOT NULL UNIQUE,   -- e.g. DLR-00142
  full_name        VARCHAR(120) NOT NULL,
  email            VARCHAR(120) NOT NULL UNIQUE,
  phone            VARCHAR(30),
  company          VARCHAR(120),
  status           VARCHAR(20)  NOT NULL DEFAULT 'pending',
    -- pending | active | suspended
  tier             VARCHAR(20)  NOT NULL DEFAULT 'base',
    -- base | silver | gold
  activations_mtd  INT          NOT NULL DEFAULT 0, -- reset monthly by CRON
  ach_routing      VARCHAR(20),                     -- stored encrypted in prod
  ach_account      VARCHAR(30),
  notes            TEXT,
  created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- ── 2. DEALER_ORDERS ────────────────────────────────────────
-- One row per order submitted by a dealer
CREATE TABLE IF NOT EXISTS dealer_orders (
  id               SERIAL PRIMARY KEY,
  dealer_id        INT          NOT NULL REFERENCES dealers(id) ON DELETE RESTRICT,
  order_ref        VARCHAR(20)  NOT NULL UNIQUE,    -- e.g. ORD-20250410-0042
  -- client info captured at order time
  client_name      VARCHAR(120) NOT NULL,
  client_email     VARCHAR(120),
  client_phone     VARCHAR(30),
  service_address  TEXT,
  -- product
  product_line     VARCHAR(60)  NOT NULL,
    -- frontier_fiber | xfinity_prepaid | verizon_prepaid |
    --   black_wireless | travelsim | sling_tv
  plan_name        VARCHAR(80),
  plan_price_cents INT,                             -- monthly plan cost
  -- spiff
  spiff_cents      INT          NOT NULL DEFAULT 0,
  tier_at_order    VARCHAR(20)  NOT NULL DEFAULT 'base',
  -- lifecycle
  status           VARCHAR(30)  NOT NULL DEFAULT 'submitted',
    -- submitted | payment_confirmed | activating |
    --   activated | cancelled | chargeback
  payment_ref      VARCHAR(120),                    -- Stripe session / prepaid receipt
  activated_at     TIMESTAMPTZ,
  notes            TEXT,
  dealer_notes     TEXT,
  created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- ── 3. COMMISSIONS ──────────────────────────────────────────
-- One row per earned commission, linked to a dealer_order
CREATE TABLE IF NOT EXISTS commissions (
  id               SERIAL PRIMARY KEY,
  dealer_id        INT          NOT NULL REFERENCES dealers(id) ON DELETE RESTRICT,
  order_id         INT          NOT NULL REFERENCES dealer_orders(id) ON DELETE RESTRICT,
  amount_cents     INT          NOT NULL,
  status           VARCHAR(20)  NOT NULL DEFAULT 'pending',
    -- pending | approved | paid | reversed
  approved_at      TIMESTAMPTZ,
  paid_at          TIMESTAMPTZ,
  payout_id        INT,                             -- FK to dealer_payouts.id once paid
  notes            TEXT,
  created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- ── 4. DEALER_PAYOUTS ───────────────────────────────────────
-- One row per ACH batch sent to a dealer
CREATE TABLE IF NOT EXISTS dealer_payouts (
  id               SERIAL PRIMARY KEY,
  dealer_id        INT          NOT NULL REFERENCES dealers(id) ON DELETE RESTRICT,
  amount_cents     INT          NOT NULL,
  commission_count INT          NOT NULL DEFAULT 0,
  status           VARCHAR(20)  NOT NULL DEFAULT 'pending',
    -- pending | processing | sent | failed
  ach_batch_ref    VARCHAR(80),                     -- external ACH reference
  initiated_at     TIMESTAMPTZ,
  sent_at          TIMESTAMPTZ,
  notes            TEXT,
  created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- ── 5. SPIFF_SCHEDULE ───────────────────────────────────────
-- Admin-editable spiff rates per product and tier
CREATE TABLE IF NOT EXISTS spiff_schedule (
  id               SERIAL PRIMARY KEY,
  product_line     VARCHAR(60)  NOT NULL,
  tier             VARCHAR(20)  NOT NULL DEFAULT 'base',
  spiff_cents      INT          NOT NULL,
  markets          VARCHAR(120) DEFAULT 'Nationwide',
  notes            VARCHAR(255),
  active           BOOLEAN      NOT NULL DEFAULT TRUE,
  effective_from   DATE         NOT NULL DEFAULT CURRENT_DATE,
  created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  UNIQUE (product_line, tier, effective_from)
);

-- ── INDEXES ─────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_dealer_orders_dealer    ON dealer_orders(dealer_id);
CREATE INDEX IF NOT EXISTS idx_dealer_orders_status    ON dealer_orders(status);
CREATE INDEX IF NOT EXISTS idx_commissions_dealer      ON commissions(dealer_id);
CREATE INDEX IF NOT EXISTS idx_commissions_status      ON commissions(status);
CREATE INDEX IF NOT EXISTS idx_dealer_payouts_dealer   ON dealer_payouts(dealer_id);

-- ── SEED: default spiff schedule ────────────────────────────
INSERT INTO spiff_schedule (product_line, tier, spiff_cents, markets, notes) VALUES
  ('frontier_fiber',   'base',   10000, 'TX, LA, NC',      'Per install, prepaid monthly'),
  ('frontier_fiber',   'gold',   12000, 'TX, LA, NC',      'Gold tier +20%'),
  ('xfinity_prepaid',  'base',    3500, 'Xfinity markets', 'No credit check required'),
  ('xfinity_prepaid',  'gold',    4200, 'Xfinity markets', 'Gold tier +20%'),
  ('verizon_prepaid',  'base',    3000, 'Nationwide',      'Per activation'),
  ('verizon_prepaid',  'gold',    3600, 'Nationwide',      'Gold tier +20%'),
  ('black_wireless',   'base',    2000, 'Nationwide',      'Per activation'),
  ('black_wireless',   'gold',    2400, 'Nationwide',      'Gold tier +20%'),
  ('travelsim',        'base',    1500, 'Worldwide',       'Digital fulfillment'),
  ('travelsim',        'gold',    1800, 'Worldwide',       'Gold tier +20%'),
  ('sling_tv',         'base',    1200, 'Nationwide',      'Per new subscriber'),
  ('sling_tv',         'gold',    1400, 'Nationwide',      'Gold tier +20%')
ON CONFLICT (product_line, tier, effective_from) DO NOTHING;

-- ── MONTHLY RESET FUNCTION ───────────────────────────────────
-- Call via pg_cron or N8N schedule on the 1st of each month
CREATE OR REPLACE FUNCTION reset_dealer_activations_mtd()
RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  UPDATE dealers SET activations_mtd = 0, updated_at = NOW();
END;
$$;

-- ── TIER AUTO-UPDATE FUNCTION ────────────────────────────────
-- Called after each activation to keep tier current
CREATE OR REPLACE FUNCTION update_dealer_tier(p_dealer_id INT)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE
  v_count INT;
BEGIN
  SELECT activations_mtd INTO v_count FROM dealers WHERE id = p_dealer_id;
  UPDATE dealers SET
    tier = CASE
      WHEN v_count >= 10 THEN 'gold'
      WHEN v_count >= 5  THEN 'silver'
      ELSE 'base'
    END,
    updated_at = NOW()
  WHERE id = p_dealer_id;
END;
$$;
