# Dealer Module — Integration Guide
## bm-cportal on dal-coolify-02

---

## Step 1 — Run the migration

SSH into dal-coolify-02 or run from your Coder terminal:

```bash
psql $DATABASE_URL -f migrations/001_dealer_module.sql
```

This creates 5 new tables and seeds the default spiff schedule. Safe to run on a live DB — all `CREATE TABLE IF NOT EXISTS`.

Tables created:
- `dealers`
- `dealer_orders`
- `commissions`
- `dealer_payouts`
- `spiff_schedule`

---

## Step 2 — Add the route file

Copy `routes/dealer.js` into your portal project:

```
bm-cportal/
  routes/
    dealer.js   ← new file
```

---

## Step 3 — Mount in app.js

Open `app.js` and add alongside your existing routes:

```javascript
const dealerRoutes = require('./routes/dealer');

// Dealer self-service API
app.use('/api/dealer', dealerRoutes);

// Webhook endpoint (same pattern as existing /api/webhook routes)
app.use('/api/webhook', dealerRoutes);
```

---

## Step 4 — Add 'dealer' role to your session/auth

In your login handler, when a dealer logs in set:

```javascript
req.session.role      = 'dealer';
req.session.dealer_id = dealer.id;  // from dealers table
```

Dealers and admin/client users share the same login page — the role field routes them to the right dashboard.

---

## Step 5 — Add env variable (already exists)

The module uses `WEBHOOK_SECRET` — this is the same value already set in Coolify for your existing webhook endpoints. No new secrets needed.

---

## Step 6 — Wire N8N activation webhook

In Coolify → N8N → your CLOUDMASTER or UISP activation flow, add the HTTP Request node from `n8n/dealer_activation_node.json` at the **end** of the activation sequence (after service is confirmed live).

This is what auto-approves commissions — without it, you'd have to approve manually.

Two matching strategies (use whichever is available in your flow):
1. `order_ref` — most accurate, requires dealer to submit via portal first
2. `client_email` + `product_line` — fallback for walk-in/phone orders

---

## Step 7 — Weekly payout N8N workflow

Create a new N8N workflow:
- Trigger: Schedule — every Friday 9:00 AM CT
- Node: HTTP Request POST to `https://portal.bluemogul.us/api/dealer/admin/run-payouts`
- Header: `x-webhook-token: YOUR_WEBHOOK_SECRET`

This batches all approved commissions into payout records. Actual ACH transfer is a manual step until you connect a payment processor (Stripe Connect or Relay).

---

## API Reference

| Method | Endpoint | Auth | Purpose |
|--------|----------|------|---------|
| POST | `/api/dealer/register` | Public | Dealer signs up |
| GET | `/api/dealer/dashboard` | Dealer | Stats + recent orders |
| GET | `/api/dealer/spiffs` | Public | Current spiff schedule |
| POST | `/api/dealer/orders` | Dealer | Submit new order |
| GET | `/api/dealer/commissions` | Dealer | Commission log |
| GET | `/api/dealer/payouts` | Dealer | Payout history |
| POST | `/api/dealer/payouts/request` | Dealer | Early payout request |
| POST | `/api/webhook/dealer-activation` | Webhook token | N8N activation trigger |
| POST | `/api/dealer/admin/approve/:id` | Admin | Approve dealer signup |
| GET | `/api/dealer/admin/pending` | Admin | Pending signups list |
| POST | `/api/dealer/admin/run-payouts` | Admin | Trigger weekly batch |

---

## Tier Logic

| Activations/month | Tier | Spiff multiplier |
|---|---|---|
| 0–4 | Base | 1x |
| 5–9 | Silver | 1x (visual only — use gold multiplier for pay bump) |
| 10+ | Gold | +20% on all spiffs |

Tier resets on the 1st of each month via `reset_dealer_activations_mtd()`. Wire this to N8N with a monthly schedule trigger.

---

## What's NOT included (Phase 2)

- Dealer-facing PHP pages (dealer-dashboard.php, dealer-orders.php) — build these in your portal's existing PHP/HTML template style
- Stripe Connect for automated ACH payouts (currently payout records are created; actual transfer is manual)
- Dealer onboarding email via HERALD agent
- Admin dealer management page in the portal UI
