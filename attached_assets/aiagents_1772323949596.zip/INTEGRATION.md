# Blue Mogul AI Agent Army — Backend Integration Guide

## File Structure (drop into your Replit project)

```
your-replit-portal/
├── db.php                          ← Core DB connection (shared helper)
├── setup.php                       ← Run ONCE to init DB, then delete
├── schema.sql                      ← PostgreSQL schema + agent seed data
├── api/
│   └── agents.php                  ← Main REST API (all agent endpoints)
├── api/webhook/
│   ├── agent-log.php               ← N8N → Portal: log agent runs
│   ├── create-ticket.php           ← N8N → Portal: create support tickets
│   └── notify.php                  ← N8N → Portal: push notifications
└── cron/
    └── daily-reset.php             ← Nightly counter reset
```

---

## Step 1: Add to Replit Secrets

In your Replit project → Secrets tab, add:

| Key                  | Value                        | Purpose                        |
|----------------------|------------------------------|--------------------------------|
| `DATABASE_URL`       | (already set by Replit)      | PostgreSQL connection          |
| `N8N_WEBHOOK_SECRET` | any strong random string     | Authenticates N8N → Portal     |
| `CRON_SECRET`        | any strong random string     | Protects cron endpoint         |
| `SETUP_SECRET`       | any string (temp)            | Protects setup.php (optional)  |

---

## Step 2: Initialize the Database

1. Upload all files to your Replit project
2. Visit: `https://your-app.replit.dev/setup.php`
3. Confirm all ✅ green — 10 agents seeded, metrics rows created
4. Delete `setup.php` immediately after

---

## Step 3: Wire Up Your Frontend

Your existing `admin-ai-agents.php` dashboard needs to call these endpoints.

### Fetch Agent Status Board
```javascript
const agents = await fetch('/api/agents.php?action=list')
  .then(r => r.json());
// agents.agents[] — array of all 10 agents with metrics
```

### Fetch Dashboard Totals (top 4 cards)
```javascript
const stats = await fetch('/api/agents.php?action=dashboard')
  .then(r => r.json());
// stats.total_agents, stats.online_count, stats.total_hrs_saved
// stats.success_rate, stats.monthly_revenue, stats.annual_revenue
```

### Fetch Recent Activity Feed
```javascript
const activity = await fetch('/api/agents.php?action=activity?limit=20')
  .then(r => r.json());
// activity.activity[] — recent agent runs
```

### Fetch ROI Calculator Data
```javascript
const roi = await fetch('/api/agents.php?action=roi')
  .then(r => r.json());
// roi.agents[], roi.total_hrs_week, roi.infra_stack[]
```

### "Run Orchestrator" Button
```javascript
async function runOrchestrator() {
  const res = await fetch('/api/agents.php?action=run_all', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }).then(r => r.json());
  // res.triggered = 10 (all agents fired)
}
```

### Trigger Single Agent
```javascript
async function runAgent(agentKey) {
  const res = await fetch(`/api/agents.php?action=run&key=${agentKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }).then(r => r.json());
}
```

---

## Step 4: Configure N8N Webhooks

### N8N → Portal (agents report results back)

In each N8N workflow, add an **HTTP Request** node at the END:

| Field       | Value                                                     |
|-------------|-----------------------------------------------------------|
| Method      | POST                                                      |
| URL         | `https://your-app.replit.dev/api/webhook/agent-log.php`   |
| Header      | `X-Webhook-Secret: YOUR_N8N_WEBHOOK_SECRET`               |
| Body (JSON) | `{"agent_key":"sentinel","action":"...","status":"success","message":"...","execution_ms":1200}` |

### Portal → N8N (dashboard triggers agents)

For each agent, set its N8N webhook URL in the database:

```sql
UPDATE agent_config
SET n8n_webhook_url = 'https://your-n8n.coolify.io/webhook/sentinel-trigger'
WHERE agent_key = 'sentinel';
```

Or via API:
```javascript
fetch('/api/agents.php?action=update_webhook', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    agent_key: 'sentinel',
    webhook_url: 'https://your-n8n.coolify.io/webhook/sentinel-trigger'
  })
});
```

### N8N Ticket Creation (SENTINEL/GUARDIAN)
```json
POST /api/webhook/create-ticket.php
X-Webhook-Secret: YOUR_SECRET

{
  "agent_key":    "sentinel",
  "client_name":  "ABC Dental",
  "subject":      "High CPU on SERVER-01",
  "description":  "CPU at 97% for 10 min. Auto-remediation failed.",
  "priority":     "high",
  "device_name":  "SERVER-01"
}
```

---

## Step 5: Nightly Cron (Reset Daily Counters)

Add an N8N workflow triggered at midnight:
- **Schedule Trigger**: 0 0 * * *
- **HTTP Request**: POST `https://your-app.replit.dev/cron/daily-reset.php`
- **Header**: `X-Cron-Secret: YOUR_CRON_SECRET`

---

## API Quick Reference

| Endpoint                                      | Method | Description                    |
|-----------------------------------------------|--------|--------------------------------|
| `/api/agents.php?action=list`                 | GET    | All agents + live metrics      |
| `/api/agents.php?action=dashboard`            | GET    | Top stats (online, saves, ROI) |
| `/api/agents.php?action=activity&limit=20`    | GET    | Recent activity feed           |
| `/api/agents.php?action=roi`                  | GET    | ROI calculator + infra stack   |
| `/api/agents.php?action=get&key=sentinel`     | GET    | Single agent + last 20 logs    |
| `/api/agents.php?action=run&key=sentinel`     | POST   | Trigger single agent           |
| `/api/agents.php?action=run_all`              | POST   | Trigger all (Orchestrator)     |
| `/api/agents.php?action=update_webhook`       | POST   | Set agent's N8N webhook URL    |
| `/api/webhook/agent-log.php`                  | POST   | N8N posts execution results    |
| `/api/webhook/create-ticket.php`              | POST   | N8N creates tickets            |
| `/api/webhook/notify.php`                     | POST   | N8N pushes notifications       |
| `/cron/daily-reset.php`                       | POST   | Reset daily run counters       |

---

## Troubleshooting

**"DATABASE_URL not set"** → Check Replit Secrets tab  
**"Unauthorized" on webhooks** → Verify `N8N_WEBHOOK_SECRET` matches in both Replit and N8N  
**Agents show 0 runs** → N8N hasn't posted back yet; trigger manually once  
**Webhook delivery fails** → Check `n8n_webhook_url` is set per agent in `agent_config`
