<?php
/**
 * Blue Mogul — N8N Ticket Creation Webhook
 * Place at: /api/webhook/create-ticket.php
 *
 * Called by N8N (SENTINEL, GUARDIAN agents) to create support tickets.
 *
 * POST body:
 * {
 *   "agent_key":    "sentinel",
 *   "client_name":  "ABC Dental",
 *   "subject":      "High CPU on SERVER-01",
 *   "description":  "CPU at 97% for 10 minutes...",
 *   "priority":     "high",     // low | medium | high | critical
 *   "category":     "monitoring",
 *   "device_name":  "SERVER-01",
 *   "auto_created": true
 * }
 */

require_once __DIR__ . '/../../db.php';

require_method('POST');

$secret = getenv('N8N_WEBHOOK_SECRET');
if ($secret) {
    $incoming = $_SERVER['HTTP_X_WEBHOOK_SECRET'] ?? '';
    if ($incoming !== $secret) json_response(['error' => 'Unauthorized'], 401);
}

$body = get_request_body();

$agent_key   = $body['agent_key']   ?? 'sentinel';
$client_name = $body['client_name'] ?? 'Unknown Client';
$subject     = $body['subject']     ?? 'AI-Generated Ticket';
$description = $body['description'] ?? '';
$priority    = in_array($body['priority'] ?? '', ['low','medium','high','critical'])
               ? $body['priority'] : 'medium';
$category    = $body['category']    ?? 'general';
$device_name = $body['device_name'] ?? '';
$auto        = (bool)($body['auto_created'] ?? true);

$db = get_db();

// Log in agent_logs
$db->prepare("
    INSERT INTO agent_logs (agent_key, action, status, message, metadata)
    VALUES (?, 'Create ticket', 'success', ?, ?)
")->execute([
    $agent_key,
    "Created ticket: $subject for $client_name",
    json_encode([
        'client'   => $client_name,
        'priority' => $priority,
        'device'   => $device_name,
        'category' => $category,
    ]),
]);

// Activity log
$db->prepare("
    INSERT INTO activity_log (actor, action, entity_type, details, metadata)
    VALUES (?, ?, 'ticket', ?, ?)
")->execute([
    "agent:{$agent_key}",
    "Auto-created ticket: $subject",
    "Client: $client_name | Priority: $priority | Device: $device_name",
    json_encode($body),
]);

// Update metrics
$db->prepare("
    INSERT INTO agent_metrics (agent_key, runs_total, runs_today, last_status, last_run_at, online, updated_at)
    VALUES (?, 1, 1, 'success', NOW(), TRUE, NOW())
    ON CONFLICT (agent_key) DO UPDATE SET
        runs_total  = agent_metrics.runs_total + 1,
        runs_today  = agent_metrics.runs_today + 1,
        last_status = 'success',
        last_run_at = NOW(),
        online      = TRUE,
        updated_at  = NOW()
")->execute([$agent_key]);

json_response([
    'success'     => true,
    'ticket_created' => true,
    'subject'     => $subject,
    'client'      => $client_name,
    'priority'    => $priority,
    'auto_created'=> $auto,
    'timestamp'   => date('c'),
]);
