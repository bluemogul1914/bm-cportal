<?php
/**
 * Blue Mogul AI Agent Army — Main API Router
 * Drop in portal root as: /api/agents.php
 *
 * Routes (set via ?action= or URL routing):
 *   GET  ?action=list              — All agents with metrics
 *   GET  ?action=get&key=sentinel  — Single agent detail
 *   GET  ?action=dashboard         — Top-level dashboard stats
 *   GET  ?action=activity          — Recent activity feed
 *   GET  ?action=roi               — ROI calculator data
 *   POST ?action=run&key=sentinel  — Trigger agent via N8N
 *   POST ?action=run_all           — Trigger orchestrator (all agents)
 *   PUT  ?action=update_webhook    — Update N8N webhook URL for an agent
 */

require_once __DIR__ . '/../db.php';

$action = $_GET['action'] ?? 'list';
$key    = $_GET['key']    ?? '';

switch ($action) {

    // ── GET: All agents with live metrics ──────────────────────────────
    case 'list':
        require_method('GET');
        $db = get_db();

        $rows = $db->query("
            SELECT
                ac.*,
                COALESCE(am.runs_total,     0)        AS runs_total,
                COALESCE(am.runs_today,     0)        AS runs_today,
                COALESCE(am.errors_total,   0)        AS errors_total,
                COALESCE(am.saves_week_hrs, ac.time_saved_hrs::DECIMAL) AS saves_week_hrs,
                COALESCE(am.online,         FALSE)    AS online,
                COALESCE(am.last_status,    'idle')   AS last_status,
                am.last_run_at
            FROM agent_config ac
            LEFT JOIN agent_metrics am ON am.agent_key = ac.agent_key
            WHERE ac.is_enabled = TRUE
            ORDER BY ac.id ASC
        ")->fetchAll();

        // Parse tools array from postgres string format
        foreach ($rows as &$row) {
            $row['tools'] = parse_pg_array($row['tools']);
            $row['config_json'] = json_decode($row['config_json'] ?? '{}', true);
        }

        json_response(['agents' => $rows, 'count' => count($rows)]);
        break;

    // ── GET: Single agent detail + recent logs ─────────────────────────
    case 'get':
        require_method('GET');
        if (!$key) json_response(['error' => 'key required'], 400);

        $db  = get_db();
        $stmt = $db->prepare("
            SELECT ac.*, am.runs_total, am.runs_today, am.errors_total,
                   am.saves_week_hrs, am.online, am.last_status, am.last_run_at
            FROM agent_config ac
            LEFT JOIN agent_metrics am ON am.agent_key = ac.agent_key
            WHERE ac.agent_key = ?
        ");
        $stmt->execute([$key]);
        $agent = $stmt->fetch();
        if (!$agent) json_response(['error' => 'Agent not found'], 404);

        $agent['tools']       = parse_pg_array($agent['tools']);
        $agent['config_json'] = json_decode($agent['config_json'] ?? '{}', true);

        // Last 20 logs for this agent
        $logStmt = $db->prepare("
            SELECT id, action, status, message, execution_ms, created_at
            FROM agent_logs
            WHERE agent_key = ?
            ORDER BY created_at DESC
            LIMIT 20
        ");
        $logStmt->execute([$key]);
        $agent['recent_logs'] = $logStmt->fetchAll();

        json_response($agent);
        break;

    // ── GET: Dashboard top-level stats ────────────────────────────────
    case 'dashboard':
        require_method('GET');
        $db = get_db();

        $totals = $db->query("
            SELECT
                COUNT(*)                                          AS total_agents,
                SUM(CASE WHEN am.online THEN 1 ELSE 0 END)       AS online_count,
                SUM(ac.time_saved_hrs)                           AS total_hrs_saved,
                SUM(COALESCE(am.runs_total, 0))                  AS total_runs,
                SUM(CASE WHEN am.last_status = 'error' THEN 1 ELSE 0 END) AS error_count
            FROM agent_config ac
            LEFT JOIN agent_metrics am ON am.agent_key = ac.agent_key
            WHERE ac.is_enabled = TRUE
        ")->fetch();

        $revenue = $db->query("
            SELECT SUM(revenue_monthly) AS total_monthly_revenue
            FROM agent_config
            WHERE is_enabled = TRUE AND agent_key != 'orchestrator'
        ")->fetch();

        // Success rate from last 500 logs
        $rate = $db->query("
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) AS successes
            FROM (SELECT status FROM agent_logs ORDER BY created_at DESC LIMIT 500) t
        ")->fetch();

        $success_rate = ($rate['total'] > 0)
            ? round(($rate['successes'] / $rate['total']) * 100)
            : 100;

        json_response([
            'total_agents'    => (int)$totals['total_agents'],
            'online_count'    => (int)$totals['online_count'],
            'total_hrs_saved' => (int)$totals['total_hrs_saved'],
            'total_runs'      => (int)$totals['total_runs'],
            'success_rate'    => $success_rate,
            'monthly_revenue' => (float)($revenue['total_monthly_revenue'] ?? 15800),
            'annual_revenue'  => (float)($revenue['total_monthly_revenue'] ?? 15800) * 12,
            'fte_equivalent'  => round((int)$totals['total_hrs_saved'] / 40, 1),
            'cost_savings_lo' => 7800,
            'cost_savings_hi' => 26400,
        ]);
        break;

    // ── GET: Recent activity feed ──────────────────────────────────────
    case 'activity':
        require_method('GET');
        $db    = get_db();
        $limit = min((int)($_GET['limit'] ?? 20), 100);

        $rows = $db->prepare("
            SELECT
                al.id,
                al.agent_key,
                al.action,
                al.status,
                al.message,
                al.created_at,
                ac.agent_name,
                ac.icon
            FROM agent_logs al
            LEFT JOIN agent_config ac ON ac.agent_key = al.agent_key
            ORDER BY al.created_at DESC
            LIMIT ?
        ");
        $rows->execute([$limit]);

        json_response(['activity' => $rows->fetchAll()]);
        break;

    // ── GET: ROI calculator data ───────────────────────────────────────
    case 'roi':
        require_method('GET');
        $db = get_db();

        $agents = $db->query("
            SELECT agent_key, agent_name, icon, time_saved_hrs, revenue_label
            FROM agent_config
            WHERE is_enabled = TRUE
            ORDER BY time_saved_hrs DESC
        ")->fetchAll();

        $total_hrs     = array_sum(array_column($agents, 'time_saved_hrs'));
        $traditional_lo = 135000;
        $traditional_hi = 180000;

        $infra = [
            ['tool' => 'N8N (Coolify)',     'function' => 'Workflow automation', 'your_cost' => '$0',      'saas_alt' => 'Zapier',           'saas_cost' => '$49-599/mo'],
            ['tool' => 'AnythingLLM',       'function' => 'AI knowledge base',   'your_cost' => '$0',      'saas_alt' => 'ChatGPT API',      'saas_cost' => '$20-200/mo'],
            ['tool' => 'Ollama',            'function' => 'Local LLM inference', 'your_cost' => '$0',      'saas_alt' => 'OpenAI API',       'saas_cost' => '$50-500/mo'],
            ['tool' => 'Flowise (Coolify)', 'function' => 'AI agent builder',    'your_cost' => '$0',      'saas_alt' => 'Relevance AI',     'saas_cost' => '$19-199/mo'],
            ['tool' => 'ITarian',           'function' => 'RMM + patching + AV', 'your_cost' => '$0',      'saas_alt' => 'NinjaOne',         'saas_cost' => '$3-7/device/mo'],
            ['tool' => 'ITFlow (Coolify)',  'function' => 'PSA + ticketing',     'your_cost' => '$0',      'saas_alt' => 'ConnectWise',      'saas_cost' => '$100-500/mo'],
            ['tool' => 'HubSpot CRM',       'function' => 'Sales pipeline',      'your_cost' => '$0 (free)','saas_alt' => 'Salesforce',      'saas_cost' => '$25-300/user'],
            ['tool' => 'Nextcloud (Vultr)', 'function' => 'Private cloud',       'your_cost' => '$6-24/inst','saas_alt'=> 'Google Workspace', 'saas_cost' => '$6-18/user'],
            ['tool' => 'Uptime-Kuma',       'function' => 'Monitoring',          'your_cost' => '$0',      'saas_alt' => 'Pingdom',          'saas_cost' => '$10-100/mo'],
            ['tool' => 'Matrix (Coolify)',  'function' => 'Team messaging',      'your_cost' => '$0',      'saas_alt' => 'Slack',            'saas_cost' => '$7.25/user/mo'],
        ];

        json_response([
            'agents'          => $agents,
            'total_hrs_week'  => $total_hrs,
            'annual_value'    => 189600,
            'monthly_enabled' => 15800,
            'fte_equivalent'  => round($total_hrs / 40, 1),
            'salary_lo'       => $traditional_lo,
            'salary_hi'       => $traditional_hi,
            'infra_stack'     => $infra,
            'cost_lo'         => 6,
            'cost_hi'         => 24,
            'savings_lo'      => 7800,
            'savings_hi'      => 26400,
        ]);
        break;

    // ── POST: Trigger a single agent via N8N webhook ──────────────────
    case 'run':
        require_method('POST');
        if (!$key) json_response(['error' => 'key required'], 400);

        $db   = get_db();
        $body = get_request_body();

        // Fetch agent + its webhook URL
        $stmt = $db->prepare("SELECT * FROM agent_config WHERE agent_key = ? AND is_enabled = TRUE");
        $stmt->execute([$key]);
        $agent = $stmt->fetch();
        if (!$agent) json_response(['error' => 'Agent not found or disabled'], 404);

        $result = trigger_n8n_webhook($agent, $body);

        // Log the run attempt
        $logStmt = $db->prepare("
            INSERT INTO agent_logs (agent_key, action, status, message, metadata)
            VALUES (?, 'Manual trigger', ?, ?, ?)
        ");
        $logStmt->execute([
            $key,
            $result['success'] ? 'success' : 'error',
            $result['success'] ? 'Agent triggered via dashboard' : ($result['error'] ?? 'Webhook call failed'),
            json_encode(['triggered_by' => 'dashboard', 'payload' => $body])
        ]);

        // Update metrics
        update_metrics($db, $key, $result['success'] ? 'success' : 'error');

        // Activity log
        $db->prepare("
            INSERT INTO activity_log (actor, action, entity_type, entity_id, details)
            VALUES ('user:admin', ?, 'agent', ?, ?)
        ")->execute([
            "Manually triggered {$agent['agent_name']}",
            $key,
            $result['success'] ? 'Webhook delivered successfully' : 'Webhook failed: ' . ($result['error'] ?? '')
        ]);

        json_response([
            'success'    => $result['success'],
            'agent_key'  => $key,
            'agent_name' => $agent['agent_name'],
            'webhook'    => !empty($agent['n8n_webhook_url']) ? 'sent' : 'no_webhook_configured',
            'message'    => $result['message'] ?? 'Agent triggered',
        ]);
        break;

    // ── POST: Run Orchestrator (triggers all agents via N8N) ──────────
    case 'run_all':
        require_method('POST');
        $db      = get_db();
        $results = [];

        $agents = $db->query("
            SELECT * FROM agent_config WHERE is_enabled = TRUE ORDER BY id ASC
        ")->fetchAll();

        foreach ($agents as $agent) {
            $r = trigger_n8n_webhook($agent, ['triggered_by' => 'orchestrator']);
            $results[$agent['agent_key']] = $r['success'];

            // Log each
            $db->prepare("
                INSERT INTO agent_logs (agent_key, action, status, message)
                VALUES (?, 'Orchestrator trigger', ?, ?)
            ")->execute([
                $agent['agent_key'],
                $r['success'] ? 'success' : 'error',
                $r['success'] ? 'Triggered by orchestrator' : ($r['error'] ?? 'Failed')
            ]);

            update_metrics($db, $agent['agent_key'], $r['success'] ? 'success' : 'error');
        }

        $db->prepare("
            INSERT INTO activity_log (actor, action, entity_type, details)
            VALUES ('agent:orchestrator', 'Coordinated daily agent execution', 'agent', ?)
        ")->execute([json_encode($results)]);

        json_response([
            'success' => true,
            'triggered' => count($agents),
            'results'  => $results,
        ]);
        break;

    // ── PUT: Update N8N webhook URL for an agent ──────────────────────
    case 'update_webhook':
        require_method('POST', 'PUT');
        $db   = get_db();
        $body = get_request_body();
        $k    = $body['agent_key'] ?? $key;
        $url  = $body['webhook_url'] ?? '';

        if (!$k || !$url) json_response(['error' => 'agent_key and webhook_url required'], 400);
        if (!filter_var($url, FILTER_VALIDATE_URL)) json_response(['error' => 'Invalid URL'], 400);

        $stmt = $db->prepare("UPDATE agent_config SET n8n_webhook_url = ?, updated_at = NOW() WHERE agent_key = ?");
        $stmt->execute([$url, $k]);

        json_response(['success' => true, 'agent_key' => $k, 'webhook_url' => $url]);
        break;

    default:
        json_response(['error' => "Unknown action: $action"], 400);
}

// ══════════════════════════════════════════════════════════════
// Helper: Trigger N8N Webhook
// ══════════════════════════════════════════════════════════════

function trigger_n8n_webhook(array $agent, array $payload = []): array {
    $url = $agent['n8n_webhook_url'] ?? '';

    if (empty($url)) {
        // No webhook configured — still log as success (dev mode)
        return ['success' => true, 'message' => 'No webhook configured — logged only'];
    }

    $data = json_encode(array_merge($payload, [
        'agent_key'  => $agent['agent_key'],
        'agent_name' => $agent['agent_name'],
        'timestamp'  => date('c'),
        'source'     => 'blue_mogul_portal',
    ]));

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $data,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error    = curl_error($ch);
    curl_close($ch);

    if ($error) {
        return ['success' => false, 'error' => $error];
    }

    $success = $httpCode >= 200 && $httpCode < 300;
    return [
        'success'  => $success,
        'http_code'=> $httpCode,
        'response' => $response,
        'message'  => $success ? 'Webhook delivered' : "HTTP $httpCode",
    ];
}

// ══════════════════════════════════════════════════════════════
// Helper: Update agent_metrics after a run
// ══════════════════════════════════════════════════════════════

function update_metrics(PDO $db, string $key, string $status): void {
    $db->prepare("
        INSERT INTO agent_metrics (agent_key, runs_total, runs_today, errors_total, last_status, last_run_at, online, updated_at)
        VALUES (?, 1, 1, ?, ?, NOW(), TRUE, NOW())
        ON CONFLICT (agent_key) DO UPDATE SET
            runs_total   = agent_metrics.runs_total + 1,
            runs_today   = agent_metrics.runs_today + 1,
            errors_total = agent_metrics.errors_total + (CASE WHEN ? = 'error' THEN 1 ELSE 0 END),
            last_status  = ?,
            last_run_at  = NOW(),
            online       = TRUE,
            updated_at   = NOW()
    ")->execute([
        $key,
        $status === 'error' ? 1 : 0,
        $status,
        $status,
        $status,
    ]);
}

// ══════════════════════════════════════════════════════════════
// Helper: Parse PostgreSQL array string -> PHP array
// ══════════════════════════════════════════════════════════════

function parse_pg_array(mixed $val): array {
    if (is_array($val)) return $val;
    if (!$val || $val === '{}') return [];
    // Strip { } and split
    $inner = trim($val, '{}');
    if ($inner === '') return [];
    return array_map(fn($v) => trim($v, '"'), str_getcsv($inner));
}
