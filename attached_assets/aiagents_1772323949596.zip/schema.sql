-- ============================================================
-- Blue Mogul AI Agent Army — PostgreSQL Schema
-- Safe to run on your existing Replit DB (uses IF NOT EXISTS)
-- ============================================================

-- Extend agent_config if it doesn't have all columns yet
CREATE TABLE IF NOT EXISTS agent_config (
    id              SERIAL PRIMARY KEY,
    agent_key       VARCHAR(50) UNIQUE NOT NULL,
    agent_name      VARCHAR(100) NOT NULL,
    agent_role      VARCHAR(100) NOT NULL,
    description     TEXT,
    icon            VARCHAR(10),
    color           VARCHAR(20),
    n8n_webhook_url TEXT DEFAULT '',
    tools           TEXT[] DEFAULT '{}',
    time_saved_hrs  INTEGER DEFAULT 0,
    revenue_label   VARCHAR(100),
    revenue_monthly DECIMAL(10,2) DEFAULT 0,
    is_enabled      BOOLEAN DEFAULT TRUE,
    config_json     JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Add missing columns to agent_config if upgrading existing table
DO $$ BEGIN
    BEGIN ALTER TABLE agent_config ADD COLUMN agent_key VARCHAR(50); EXCEPTION WHEN duplicate_column THEN NULL; END;
    BEGIN ALTER TABLE agent_config ADD COLUMN agent_role VARCHAR(100); EXCEPTION WHEN duplicate_column THEN NULL; END;
    BEGIN ALTER TABLE agent_config ADD COLUMN icon VARCHAR(10); EXCEPTION WHEN duplicate_column THEN NULL; END;
    BEGIN ALTER TABLE agent_config ADD COLUMN color VARCHAR(20); EXCEPTION WHEN duplicate_column THEN NULL; END;
    BEGIN ALTER TABLE agent_config ADD COLUMN n8n_webhook_url TEXT DEFAULT ''; EXCEPTION WHEN duplicate_column THEN NULL; END;
    BEGIN ALTER TABLE agent_config ADD COLUMN tools TEXT[] DEFAULT '{}'; EXCEPTION WHEN duplicate_column THEN NULL; END;
    BEGIN ALTER TABLE agent_config ADD COLUMN time_saved_hrs INTEGER DEFAULT 0; EXCEPTION WHEN duplicate_column THEN NULL; END;
    BEGIN ALTER TABLE agent_config ADD COLUMN revenue_label VARCHAR(100); EXCEPTION WHEN duplicate_column THEN NULL; END;
    BEGIN ALTER TABLE agent_config ADD COLUMN revenue_monthly DECIMAL(10,2) DEFAULT 0; EXCEPTION WHEN duplicate_column THEN NULL; END;
END $$;

-- Agent execution log (also written by N8N via webhook)
CREATE TABLE IF NOT EXISTS agent_logs (
    id              SERIAL PRIMARY KEY,
    agent_key       VARCHAR(50) NOT NULL,
    action          VARCHAR(255),
    status          VARCHAR(20) DEFAULT 'success',
    message         TEXT,
    execution_ms    INTEGER,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- General activity/audit log
CREATE TABLE IF NOT EXISTS activity_log (
    id              SERIAL PRIMARY KEY,
    actor           VARCHAR(100),
    action          VARCHAR(255) NOT NULL,
    entity_type     VARCHAR(50),
    entity_id       VARCHAR(100),
    details         TEXT,
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Agent metrics rollup (updated by N8N webhook calls)
CREATE TABLE IF NOT EXISTS agent_metrics (
    id              SERIAL PRIMARY KEY,
    agent_key       VARCHAR(50) UNIQUE NOT NULL,
    runs_total      INTEGER DEFAULT 0,
    runs_today      INTEGER DEFAULT 0,
    errors_total    INTEGER DEFAULT 0,
    saves_week_hrs  DECIMAL(5,2) DEFAULT 0,
    last_run_at     TIMESTAMPTZ,
    last_status     VARCHAR(20) DEFAULT 'idle',
    online          BOOLEAN DEFAULT FALSE,
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_agent_logs_agent_key  ON agent_logs(agent_key);
CREATE INDEX IF NOT EXISTS idx_agent_logs_created_at ON agent_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_activity_log_created  ON activity_log(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_agent_metrics_key     ON agent_metrics(agent_key);

-- ============================================================
-- Seed: All 10 Blue Mogul AI Agents (upsert safe to re-run)
-- ============================================================

INSERT INTO agent_config (agent_key, agent_name, agent_role, description, icon, color, tools, time_saved_hrs, revenue_label, revenue_monthly) VALUES
('sentinel',    'SENTINEL',    'IT Monitoring Agent',       'Monitor ALL client systems 24/7, detect issues before clients notice, auto-remediate when possible, create tickets when human needed.',   '🛡️', '#3B82F6', ARRAY['ITarian','Uptime-Kuma','N8N','AnythingLLM'],   28, '+$3,000 MRR capacity',   3000.00),
('hunter',      'HUNTER',      'Lead Generation Agent',     'Continuously find, qualify, and warm up new prospects while you sleep or drive.',                                                         '🎯', '#10B981', ARRAY['N8N','AnythingLLM','HubSpot CRM'],           15, '+$2,000 pipeline/month', 2000.00),
('guardian',    'GUARDIAN',    'Support & Ticketing Agent', 'Handle support requests, route issues, auto-acknowledge. Handle 70%% of tier-1 support tickets automatically.',                         '🛟', '#F59E0B', ARRAY['ITFlow','N8N','AnythingLLM'],                20, '+$5,000 MRR capacity',   5000.00),
('closer',      'CLOSER',      'Sales Agent',               'Qualify leads, send proposals, follow up. Automate the entire sales pipeline from lead to close.',                                       '💼', '#8B5CF6', ARRAY['HubSpot','N8N','AnythingLLM'],               10, '+$1,500 closed/month',   1500.00),
('publisher',   'PUBLISHER',   'Social Media Agent',        'Maintain consistent social presence automatically. Generate and schedule content across all platforms.',                                 '📱', '#EC4899', ARRAY['N8N','AnythingLLM','Ollama'],                 5, '+$300-800/month',          550.00),
('mogul_brand', 'MOGUL BRAND', 'Marketing Agent',           'Ensure enterprise-class branding in all touchpoints. Create marketing materials and maintain brand consistency.',                        '🎨', '#EF4444', ARRAY['AnythingLLM','Flowise','N8N'],                3, '+25-40%% close rate',      500.00),
('commander',   'COMMANDER',   'Project Management Agent',  'Track projects, onboardings, orders automatically. Zero dropped projects through intelligent tracking.',                                '📊', '#6366F1', ARRAY['ITFlow','Nextcloud Deck','N8N'],              8, '+$1,000 retention',       1000.00),
('accountant',  'ACCOUNTANT',  'Bookkeeping Agent',         'Track revenue/expenses, reconcile, invoice. Zero unpaid invoices through automated collections.',                                       '💰', '#F97316', ARRAY['ITFlow','N8N','Relay Financial'],             5, '+$500 cash flow',           500.00),
('cloudmaster', 'CLOUDMASTER', 'Nextcloud Sales Agent',     'Sell & manage Nextcloud AIO private cloud services. Auto-deploy instances and manage client clouds.',                                   '☁️', '#06B6D4', ARRAY['Nextcloud','Vultr','N8N'],                   10, '+$1,500 MRR/month',       1500.00),
('orchestrator','ORCHESTRATOR','Master Agent',              'Coordinate all agents, provide daily briefings. The brain of the entire AI Agent Army.',                                                '🤖', '#A855F7', ARRAY['AnythingLLM','N8N','Flowise'],               5, 'Force multiplier',              0.00)
ON CONFLICT (agent_key) DO UPDATE SET
    agent_name      = EXCLUDED.agent_name,
    agent_role      = EXCLUDED.agent_role,
    description     = EXCLUDED.description,
    icon            = EXCLUDED.icon,
    color           = EXCLUDED.color,
    tools           = EXCLUDED.tools,
    time_saved_hrs  = EXCLUDED.time_saved_hrs,
    revenue_label   = EXCLUDED.revenue_label,
    revenue_monthly = EXCLUDED.revenue_monthly,
    updated_at      = NOW();

-- Seed metrics rows (one per agent)
INSERT INTO agent_metrics (agent_key, online, last_status, saves_week_hrs) VALUES
('sentinel',     TRUE, 'success', 28),
('hunter',       TRUE, 'success', 15),
('guardian',     TRUE, 'success', 20),
('closer',       TRUE, 'success', 10),
('publisher',    TRUE, 'success',  5),
('mogul_brand',  TRUE, 'success',  3),
('commander',    TRUE, 'success',  8),
('accountant',   TRUE, 'success',  5),
('cloudmaster',  TRUE, 'success', 10),
('orchestrator', TRUE, 'success',  5)
ON CONFLICT (agent_key) DO NOTHING;
