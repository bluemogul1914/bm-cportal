<?php
/**
 * Blue Mogul — Daily Cron Job
 * Place at: /cron/daily-reset.php
 *
 * Schedule via Replit's cron or call nightly from N8N:
 *   POST /cron/daily-reset.php
 *   Header: X-Cron-Secret: {CRON_SECRET}
 *
 * Resets runs_today counters + logs a daily summary.
 */

require_once __DIR__ . '/../db.php';

// Validate cron secret
$secret = getenv('CRON_SECRET') ?? getenv('N8N_WEBHOOK_SECRET');
if ($secret) {
    $incoming = $_SERVER['HTTP_X_CRON_SECRET'] ?? $_SERVER['HTTP_X_WEBHOOK_SECRET'] ?? '';
    if ($incoming !== $secret) {
        http_response_code(401);
        die(json_encode(['error' => 'Unauthorized']));
    }
}

$db = get_db();

// Snapshot yesterday's stats before reset
$snapshot = $db->query("
    SELECT
        SUM(runs_today)   AS total_runs,
        SUM(errors_total) AS total_errors,
        COUNT(*)          AS agents_active
    FROM agent_metrics
    WHERE online = TRUE
")->fetch();

// Reset daily counters
$db->exec("UPDATE agent_metrics SET runs_today = 0, updated_at = NOW()");

// Log the daily reset
$db->prepare("
    INSERT INTO activity_log (actor, action, entity_type, details, metadata)
    VALUES ('system:cron', 'Daily metrics reset', 'system', ?, ?)
")->execute([
    sprintf(
        'Reset complete. Yesterday: %d runs across %d agents, %d errors.',
        $snapshot['total_runs']   ?? 0,
        $snapshot['agents_active']?? 0,
        $snapshot['total_errors'] ?? 0
    ),
    json_encode($snapshot),
]);

header('Content-Type: application/json');
echo json_encode([
    'success'   => true,
    'reset_at'  => date('c'),
    'yesterday' => $snapshot,
]);
