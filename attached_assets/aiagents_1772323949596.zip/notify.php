<?php
/**
 * Blue Mogul — N8N Device Update + Notify Webhooks
 * Place at: /api/webhook/notify.php
 *
 * Called by N8N agents to push notifications and device status updates.
 *
 * POST body:
 * {
 *   "agent_key":  "sentinel",
 *   "type":       "alert" | "info" | "warning" | "success",
 *   "title":      "High disk usage detected",
 *   "message":    "CLIENT-PC-01 disk at 92%",
 *   "client_name":"ABC Dental",
 *   "metadata":   { ... }
 * }
 */

require_once __DIR__ . '/../../db.php';

require_method('POST');

$secret = getenv('N8N_WEBHOOK_SECRET');
if ($secret) {
    $incoming = $_SERVER['HTTP_X_WEBHOOK_SECRET'] ?? '';
    if ($incoming !== $secret) json_response(['error' => 'Unauthorized'], 401);
}

$body      = get_request_body();
$agent_key = $body['agent_key']  ?? 'system';
$type      = in_array($body['type'] ?? '', ['alert','info','warning','success'])
             ? $body['type'] : 'info';
$title     = $body['title']      ?? 'Agent Notification';
$message   = $body['message']    ?? '';
$client    = $body['client_name']?? '';
$metadata  = $body['metadata']   ?? [];

$db = get_db();

// Log notification
$db->prepare("
    INSERT INTO agent_logs (agent_key, action, status, message, metadata)
    VALUES (?, ?, 'success', ?, ?)
")->execute([
    $agent_key,
    "Notification: $title",
    $message,
    json_encode(array_merge($metadata, ['type' => $type, 'client' => $client])),
]);

$db->prepare("
    INSERT INTO activity_log (actor, action, entity_type, details)
    VALUES (?, ?, 'notification', ?)
")->execute([
    "agent:{$agent_key}",
    $title,
    $message . ($client ? " | Client: $client" : ''),
]);

json_response([
    'success'   => true,
    'notified'  => true,
    'type'      => $type,
    'title'     => $title,
    'timestamp' => date('c'),
]);
