<?php
/**
 * Blue Mogul — One-Time Setup Script
 * Place at: /setup.php — run ONCE, then DELETE this file
 *
 * Visit: https://your-replit-url.replit.dev/setup.php
 * Protects itself with SETUP_SECRET env var if set.
 */

require_once __DIR__ . '/db.php';

// Optional protection
$secret = getenv('SETUP_SECRET');
if ($secret && ($_GET['secret'] ?? '') !== $secret) {
    http_response_code(403);
    die('<h1>403 Forbidden</h1><p>Pass ?secret=YOUR_SETUP_SECRET in URL</p>');
}

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
<title>Blue Mogul — Agent Army Setup</title>
<style>
  body { font-family: monospace; background: #0f0f1a; color: #e0e0ff; padding: 2rem; }
  h1 { color: #6366f1; }
  .ok  { color: #10b981; }
  .err { color: #ef4444; }
  .warn{ color: #f59e0b; }
  pre  { background: #1a1a2e; padding: 1rem; border-radius: 8px; overflow-x: auto; }
</style>
</head>
<body>
<h1>🤖 Blue Mogul AI Agent Army — Database Setup</h1>
<?php

$db = get_db();
$schema = file_get_contents(__DIR__ . '/schema.sql');

// Split into individual statements
$statements = array_filter(
    array_map('trim', explode(';', $schema)),
    fn($s) => strlen($s) > 10
);

$ok = 0; $err = 0;

foreach ($statements as $sql) {
    $preview = substr(preg_replace('/\s+/', ' ', $sql), 0, 80);
    try {
        $db->exec($sql . ';');
        echo "<div class='ok'>✅ $preview...</div>\n";
        $ok++;
    } catch (PDOException $e) {
        echo "<div class='err'>❌ $preview...<br>&nbsp;&nbsp;→ " . htmlspecialchars($e->getMessage()) . "</div>\n";
        $err++;
    }
}

echo "<hr>";
echo "<h2>Summary</h2>";
echo "<p class='ok'>✅ $ok statements succeeded</p>";
if ($err) echo "<p class='err'>❌ $err statements failed</p>";

// Verify agents seeded
$count = $db->query("SELECT COUNT(*) FROM agent_config")->fetchColumn();
echo "<p class='ok'>🤖 $count agents in database</p>";

$metCount = $db->query("SELECT COUNT(*) FROM agent_metrics")->fetchColumn();
echo "<p class='ok'>📊 $metCount agent metric rows ready</p>";

?>
<hr>
<p class="warn">⚠️ Setup complete. <strong>Delete this file now:</strong> <code>rm setup.php</code></p>
<h2>Your API Endpoints:</h2>
<pre>
GET  /api/agents.php?action=list           — All agents + metrics
GET  /api/agents.php?action=dashboard      — Dashboard totals
GET  /api/agents.php?action=activity       — Recent activity feed
GET  /api/agents.php?action=roi            — ROI calculator
GET  /api/agents.php?action=get&key=AGENT  — Single agent detail

POST /api/agents.php?action=run&key=AGENT  — Trigger agent via N8N
POST /api/agents.php?action=run_all        — Run Orchestrator (all agents)
PUT  /api/agents.php?action=update_webhook — Set N8N webhook URL

POST /api/webhook/agent-log.php    — N8N posts run results here
POST /api/webhook/create-ticket.php— N8N posts new tickets here
POST /api/webhook/notify.php       — N8N posts notifications here

POST /cron/daily-reset.php         — Reset daily counters (call nightly from N8N)
</pre>
</body>
</html>
