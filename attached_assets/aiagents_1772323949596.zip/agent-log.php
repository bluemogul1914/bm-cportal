<?php
/**
 * Blue Mogul — N8N Inbound Webhook Receiver
 * Place at: /api/webhook/agent-log.php
 *
 * N8N calls this endpoint to write execution results back to the portal.
 * Also handles: /create-ticket, /update-device, /notify
 *
 * POST body (JSON):
 * {
 *   "agent_key":    "sentinel",
 *   "action":       "ITarian Alert → Auto-remediation",
 *   "status":       "success",          // success | error | running
 *   "message":      "Fixed disk space on CLIENT-PC-01",
 *   "execution_ms": 1420,
 *   "metadata":     { ... }             // any extra data
 * }
 */

require_once __DIR__ . '/../../db.php';

require_method('POST');

$body = get_request_body();

// Validate webhook secret (set N8N_WEBHOOK_SECRET in Replit Secrets)
$secret = getenv('N8N_WEBHOOK_SECRET');
if ($secret) {
    $incoming = $_SERVER['HTTP_X_WEBHOOK_SECRET'] ?? $_SERVER['HTTP_X_AGENT_KEY'] ?? '';
    if ($incoming !== $secret) {
        json_response(['error' => 'Unauthorized'], 401);
    }
}

$agent_key   = sanitize($body['agent_key']   ?? '');
$action      = sanitize($body['action']      ?? 'Automated execution');
$status      = in_array($body['status'] ?? '', ['success','error','running']) ? $body['status'] : 'success';
$message     = $body['message']     ?? '';
$exec_ms     = isset($body['execution_ms']) ? (int)$body['execution_ms'] : null;
$metadata    = $body['metadata']    ?? [];

if (!$agent_key) {
    json_response(['error' => 'agent_key is required'], 400);
}

$db = get_db();

// 1. Write to agent_logs
$db->prepare("
    INSERT INTO agent_logs (agent_key, action, status, message, execution_ms, metadata, created_at)
    VALUES (?, ?, ?, ?, ?, ?, NOW())
")->execute([
    $agent_key,
    $action,
    $status,
    $message,
    $exec_ms,
    json_encode($metadata),
]);

// 2. Update agent_metrics
$db->prepare("
    INSERT INTO agent_metrics (agent_key, runs_total, runs_today, errors_total, last_status, last_run_at, online, updated_at)
    VALUES (?, 1, 1, ?, ?, NOW(), TRUE, NOW())
    ON CONFLICT (agent_key) DO UPDATE SET
        runs_total   = agent_metrics.runs_total + 1,
        runs_today   = agent_metrics.runs_today + 1,
        errors_total = agent_metrics.errors_total + (CASE WHEN ? = 'error' THEN 1 ELSE 0 END),
        last_status  = ?,
        last_run_at  = NOW(),
        online       = TRUE,
        updated_at   = NOW()
")->execute([$agent_key, $status === 'error' ? 1 : 0, $status, $status, $status]);

// 3. Write to activity_log
$db->prepare("
    INSERT INTO activity_log (actor, action, entity_type, details, metadata, created_at)
    VALUES (?, ?, 'agent', ?, ?, NOW())
")->execute([
    "agent:{$agent_key}",
    $action,
    $message,
    json_encode(array_merge($metadata, ['status' => $status, 'execution_ms' => $exec_ms])),
]);

// 4. Fetch agent name for response
$nameStmt = $db->prepare("SELECT agent_name FROM agent_config WHERE agent_key = ?");
$nameStmt->execute([$agent_key]);
$agentName = $nameStmt->fetchColumn() ?: $agent_key;

json_response([
    'success'    => true,
    'logged'     => true,
    'agent_key'  => $agent_key,
    'agent_name' => $agentName,
    'status'     => $status,
    'timestamp'  => date('c'),
]);

function sanitize(string $val): string {
    return substr(preg_replace('/[^a-zA-Z0-9_\- ]/', '', $val), 0, 100);
}
